// Book: Represents a book class
class Book {
    constructor(title, author, isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
    }
}

//UI : Represnts all class show
class UI {
    static dsiplayBook() {
        let books = Store.getStore();
        books.forEach((data) => {
            UI.displaylist(data);
        })
    }
    static displaylist(data) {
        let list = document.getElementById('booklist');
        let row = document.createElement('tr');

        row.innerHTML = `
       <td>${data.title}</td>
       <td>${data.author}</td>
       <td>${data.isbn}</td>
       <td><a href="#" class="btn btn-danger btn-sm delete">X</td>
       `;

        list.appendChild(row);
    }
    //clear input field and submit
    static clearFields() {
        document.querySelector('#title').value = " ";
        document.querySelector('#author').value = " ";
        document.querySelector('#isbn').value = " ";
    }
    //delelte book list
    static deleteBook(target) {
        if (target.classList.contains('delete')) {
            target.parentElement.parentElement.remove();
        }
    }
    //Alert message shows
    static showAlert(message,className){
        const div = document.createElement('div');
        div.className = `alert alert-${className}`;
        div.appendChild(document.createTextNode(message));
        const container = document.querySelector('.container');
        const form = document.querySelector('#myform');
        container.insertBefore(div,form);
        setTimeout(()=>{
            document.querySelector('.alert').remove();
        },2000)
    }

}
//Store a book 
class Store{
    static getStore(){
        let books;
        if(localStorage.getItem('books') === null){
            books =[];
        }
        else{
            books = JSON.parse(localStorage.getItem('books'));
        }
        return books;
    }

    static addStore(book){
        let books = Store.getStore();
        books.push(book);
        localStorage.setItem('books',JSON.stringify(books));
    }

    static removeStore(isbn){
        let books = Store.getStore();
        books.forEach((element,index) => {
            if(element.isbn === isbn){
                books.splice(index,1);
            }
            
        });
        localStorage.setItem('books',JSON.stringify(books));
    }
}
// Event: For display book
document.addEventListener('DOMContentLoaded', UI.displayBook);
document.querySelector('#myform').addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.querySelector('#title').value;
    const author = document.querySelector('#author').value;
    const isbn = document.querySelector('#isbn').value;

    //validate the book fields
    if(title === '' || author ==='' || isbn ===''){
       UI.showAlert("plaese fill all fields",'danger');
    }
    else{
        const book = new Book(title, author, isbn);

        UI.displaylist(book);
        
        Store.addStore(book);

        UI.showAlert("Success",'success');

        UI.clearFields();
    }
});

//Event: Delete 
document.querySelector('#booklist').addEventListener('click', (e) => {
    UI.deleteBook(e.target);
    Store.removeStore(e.target.parentElement.previousElementSibling.textContent)
    UI.showAlert("Delete successfully",'info');
});